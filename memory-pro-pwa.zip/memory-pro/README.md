# Memory Pro PWA

Flashcard app với cloze deletion, hỗ trợ offline, cài được như app trên điện thoại.

## Cấu trúc file

```
memory-pro/
├── index.html
├── manifest.json
├── sw.js
├── css/
│   └── style.css
├── js/
│   ├── tts.js
│   ├── db.js
│   ├── cards.js
│   ├── ui.js
│   └── app.js
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

## Deploy lên GitHub Pages

### Bước 1 — Tạo repository
1. Vào https://github.com → **New repository**
2. Đặt tên: `memory-pro` (hoặc tên bất kỳ)
3. Chọn **Public**
4. Nhấn **Create repository**

### Bước 2 — Upload file
**Cách dễ nhất (không cần Git):**
1. Trong repository vừa tạo, nhấn **Add file → Upload files**
2. Kéo thả **toàn bộ thư mục** `memory-pro` vào
3. Nhấn **Commit changes**

**Hoặc dùng Git:**
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TÊN_BẠN/memory-pro.git
git push -u origin main
```

### Bước 3 — Bật GitHub Pages
1. Vào **Settings** của repository
2. Chọn **Pages** (menu bên trái)
3. Source: **Deploy from a branch**
4. Branch: **main** / **(root)**
5. Nhấn **Save**

### Bước 4 — Truy cập app
Sau ~2 phút, app sẽ live tại:
```
https://TÊN_BẠN.github.io/memory-pro/
```

## Cài như app trên điện thoại
- **Android (Chrome):** Menu → "Thêm vào màn hình chính"
- **iPhone (Safari):** Nút chia sẻ → "Thêm vào màn hình chính"

## Tính năng
- ✅ Offline hoàn toàn (Service Worker)
- ✅ Lưu dữ liệu IndexedDB (không mất khi đóng app)
- ✅ Cloze deletion với gợi ý
- ✅ Text-to-Speech
- ✅ Export / Import JSON
- ✅ Weighted random theo priority
